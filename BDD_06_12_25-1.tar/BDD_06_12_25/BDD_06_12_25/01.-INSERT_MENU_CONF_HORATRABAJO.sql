USE [TRACKING]
--Insert para el nuevo menu en para reportes

INSERT INTO T_MENU(menu,id_father,path,icon,option_run,status,menu_order,distribution_id,submenu_order,target_url)
VALUES('Apro Unidades',66,'','fa fa-sticky-note',0,1,NULL, 2,NULL,'_blank')

INSERT INTO T_MENU(menu,id_father,path,icon,option_run,status,menu_order,distribution_id,submenu_order,target_url)
VALUES('Conf Horario de trabajo',198,'/ds/reporte/confhorariotrabajo','glyphicon glyphicon-stats',1,1,NULL,2,NULL,'_blank')

INSERT INTO T_PROFILE_MENU(PROFILE_ID_FK, MENU_ID_FK)
VALUES(5,198),(8,198),(9,198),(12,198),(24,198), --MENU Aprov Unidades
      (5,199),(8,199),(9,199),(12,199),(24,199)  --MENU Conf Horario de Trabajo