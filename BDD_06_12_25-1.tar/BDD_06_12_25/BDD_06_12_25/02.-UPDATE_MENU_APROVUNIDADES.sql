USE [TRACKING]
--se hace actualiza el menu de Aprov Unidades para cambio a submenu 
UPDATE T_MENU  SET id_father = 198 WHERE id_menu = 91 AND id_father = 66