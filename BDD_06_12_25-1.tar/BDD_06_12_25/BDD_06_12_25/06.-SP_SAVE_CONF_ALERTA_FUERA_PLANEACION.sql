﻿
USE [TRACKING]
 	IF OBJECT_ID('dbo.SP_SAVE_CONF_ALERTA_FUERA_PLANEACION') IS NULL --Validar si existe el procedimiento
 		EXEC('CREATE PROCEDURE dbo.SP_SAVE_CONF_ALERTA_FUERA_PLANEACION AS SET NOCOUNT ON;') --Crear una definicion vacia del procedimiento
 		EXEC('GRANT EXECUTE ON dbo.SP_SAVE_CONF_ALERTA_FUERA_PLANEACION TO [db_executor] WITH GRANT OPTION')	--Dar permisos de ejecucion al procedimiento
 	GO
ALTER PROCEDURE dbo.SP_SAVE_CONF_ALERTA_FUERA_PLANEACION
    @ID_DUENO           INT,
    @DUENO              VARCHAR(100),
    @TIEMPO_SEGUNDOS    INT,
    @ACTIVO             BIT,
    @USUARIO            VARCHAR(100),
    @CODIGO_RESULTADO   INT OUTPUT,
    @ESTADO             VARCHAR(20) OUTPUT,
    @MENSAJE            VARCHAR(200) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        -- Validación
        IF @TIEMPO_SEGUNDOS < 240
        BEGIN
            SET @CODIGO_RESULTADO = -1;
            SET @ESTADO = 'ERROR';
            SET @MENSAJE = 'El valor de TIEMPO_SEGUNDOS debe ser al menos 240 segundos (4 minutos).';
            RETURN;
        END;

        IF EXISTS (SELECT 1 FROM dbo.TBL_CONF_ALERTA_FUERA_PLANEACION WHERE ID_DUENO = @ID_DUENO)
        BEGIN
            UPDATE dbo.TBL_CONF_ALERTA_FUERA_PLANEACION
            SET DUENO = @DUENO,
                TIEMPO_SEGUNDOS = @TIEMPO_SEGUNDOS,
                ACTIVO = @ACTIVO,
                USUARIO_MODIFICACION = @USUARIO,
                FECHA_MODIFICACION = SYSDATETIMEOFFSET()
            WHERE ID_DUENO = @ID_DUENO;

            SET @ESTADO = 'ACTUALIZADO';
            SET @CODIGO_RESULTADO = 2;
            SET @MENSAJE = 'Registro actualizado correctamente.';
        END
        ELSE
        BEGIN
            INSERT INTO dbo.TBL_CONF_ALERTA_FUERA_PLANEACION
                (ID_DUENO, DUENO, TIEMPO_SEGUNDOS, ACTIVO, USUARIO_CREACION, FECHA_CREACION)
            VALUES
                (@ID_DUENO, @DUENO, @TIEMPO_SEGUNDOS, @ACTIVO, @USUARIO, SYSDATETIMEOFFSET());

            SET @ESTADO = 'INSERTADO';
            SET @CODIGO_RESULTADO = 1;
            SET @MENSAJE = 'Registro insertado correctamente.';
        END

        -- Result set opcional con el estado final de la fila
        SELECT
            ID,
            ID_DUENO,
            DUENO,
            TIEMPO_SEGUNDOS,
            ACTIVO,
            USUARIO_CREACION,
            FECHA_CREACION,
            USUARIO_MODIFICACION,
            FECHA_MODIFICACION
        FROM dbo.TBL_CONF_ALERTA_FUERA_PLANEACION
        WHERE ID_DUENO = @ID_DUENO;
    END TRY
    BEGIN CATCH
        SET @CODIGO_RESULTADO = -1;
        SET @ESTADO = 'ERROR';
        SET @MENSAJE = ERROR_MESSAGE();
    END CATCH
END;
GO

