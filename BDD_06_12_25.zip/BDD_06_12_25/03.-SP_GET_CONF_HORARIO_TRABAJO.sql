USE [MONITOR]
GO
/****** Object:  StoredProcedure [dbo].[SP_GET_CONF_HORARIO_TRABAJO]    Script Date: 14/11/2025 04:45:51 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.SP_GET_CONF_HORARIO_TRABAJO') IS NULL --Validar si existe el procedimiento
		EXEC('CREATE PROCEDURE dbo.SP_GET_CONF_HORARIO_TRABAJO AS SET NOCOUNT ON;') --Crear una definicion vacia del procedimiento
		EXEC('GRANT EXECUTE ON dbo.SP_GET_CONF_HORARIO_TRABAJO TO [db_executor] WITH GRANT OPTION')	--Dar permisos de ejecucion al procedimiento
GO
ALTER PROCEDURE [dbo].[SP_GET_CONF_HORARIO_TRABAJO]
                 @search		   NVARCHAR(250),
	             @column     	   NVARCHAR(250),
	             @direction		   NVARCHAR(5),
	             @pageStart		   INT,
	             @pageSize		   INT,
	             @recordsTotal     INT OUT,
	             @recordsFiltered  INT OUT
AS
BEGIN
    
	DECLARE @filteredSql nvarchar(max);

	IF OBJECT_ID('tempdb..#tmp_horario_trabajo') IS NULL
	CREATE TABLE #tmp_horario_trabajo
	 ( 
	       id_tipos         INT,
		   dueno            VARCHAR(255),
		   tipos            VARCHAR(50),
		   horario_trabajo  INT,
	  );

    INSERT INTO  #tmp_horario_trabajo
	SELECT TC.ID_TIPO_CARGA AS ID_TIPOS,
	       D.dueno AS DUENO,
		   CONCAT(CT.TIPOS, 'T') AS TIPOS,
		   TC.HORARIO_DE_TRABAJO AS HORARIO_TRABAJO
	FROM TBL_TIPO_CARGA_OXXO TC
	INNER JOIN TBL_DUENO D ON TC.DUENO_ID = D.id_dueno
	INNER JOIN TBL_CAT_TIPOS_CARGA_OXXO CT ON TC.FK_TIPO_CARGA = CT.ID_TIPOS_CARGA

	--SELECT * FROM #tmp_horario_trabajo;

	SET @recordsTotal = @@ROWCOUNT;
	DECLARE @sql						nvarchar(MAX);
	DECLARE @sqlForCount				nvarchar(MAX);
	DECLARE @sqlCount					nvarchar(MAX);
	DECLARE @size						nvarchar(255)  = @PageSize;
	DECLARE @rowInit					nvarchar(255)  = @pageStart;
	DECLARE @andColumnsSearch			nvarchar(max)  = '';
	DECLARE @preparedSearch				nvarchar(255)  = char(39) + char(37) + @search + char(37) + char(39);
	DECLARE @orderBy					nvarchar(255)  = '
		ORDER BY ' + @column + ' ' + @direction + ' ';
	DECLARE @offset              nvarchar(255)  = '
		OFFSET cast(' + @rowInit +  ' as int) ROWS FETCH NEXT cast(' + @size + ' as int) ROWS ONLY';

	IF @search != ''
		SET @andColumnsSearch = '
		AND ( 
			dueno like '		   + @preparedSearch + ' OR
			tipos like '		   + @preparedSearch + ' OR 
			horario_trabajo like ' + @preparedSearch + '  
		)';
	 
	SET @sql = CONCAT('SELECT dueno, tipos, horario_trabajo FROM  #tmp_horario_trabajo  WHERE 1 = 1 ', @andColumnsSearch);

	SET @sqlForCount = CONCAT('SELECT *  FROM #tmp_horario_trabajo SQ WHERE 1 = 1 ', @andColumnsSearch);

	SET @sqlCount = CONCAT('SELECT @count=COUNT(*) FROM (',@sqlForCount,') a');
	EXECUTE sp_executesql @sqlCount, N'@count int OUTPUT', @count = @recordsFiltered OUTPUT;

	SET @sql = CONCAT( @sql, @orderBy, @offset );

	PRINT @sql;

	EXECUTE(@sql);

	DROP TABLE #tmp_horario_trabajo;
END