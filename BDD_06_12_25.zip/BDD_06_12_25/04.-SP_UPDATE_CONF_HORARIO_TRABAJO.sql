USE [MONITOR]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.SP_UPDATE_CONF_HORARIO_TRABAJO') IS NULL --Validar si existe el procedimiento
		EXEC('CREATE PROCEDURE dbo.SP_UPDATE_CONF_HORARIO_TRABAJO AS SET NOCOUNT ON;') --Crear una definicion vacia del procedimiento
		EXEC('GRANT EXECUTE ON dbo.SP_UPDATE_CONF_HORARIO_TRABAJO TO [db_executor] WITH GRANT OPTION')	--Dar permisos de ejecucion al procedimiento
GO
ALTER PROCEDURE [dbo].[SP_UPDATE_CONF_HORARIO_TRABAJO]
                      @id_conf     INT,
                      @val_horario INT
 
AS
BEGIN
  
	 UPDATE 
	 TBL_TIPO_CARGA_OXXO  SET HORARIO_DE_TRABAJO = @val_horario
     WHERE ID_TIPO_CARGA = @id_conf;

END
