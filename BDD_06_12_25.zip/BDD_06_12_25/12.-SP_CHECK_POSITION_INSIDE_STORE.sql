USE [TRACKING]
    IF OBJECT_ID('dbo.SP_CHECK_POSITION_INSIDE_STORE') IS NULL --Validar si existe el procedimiento
        EXEC('CREATE PROCEDURE dbo.SP_CHECK_POSITION_INSIDE_STORE AS SET NOCOUNT ON;') --Crear una definicion vacia del procedimiento
        EXEC('GRANT EXECUTE ON dbo.SP_CHECK_POSITION_INSIDE_STORE TO [db_executor] WITH GRANT OPTION')    --Dar permisos de ejecucion al procedimiento
    GO
ALTER PROCEDURE dbo.SP_CHECK_POSITION_INSIDE_STORE
(
    @truck_id          VARCHAR(50),
    @latitude          FLOAT,
    @longitude         FLOAT,
    @position_date     DATETIME2(0),  -- fecha/hora de la nueva posici�n
    @threshold_seconds INT            -- umbral en SEGUNDOS (viene por input)
)
AS
BEGIN
    SET NOCOUNT ON;
    -------------------------------------------------------------------------
    -- 1) Geocerca -> LOCATION_ID
    -------------------------------------------------------------------------
    DECLARE @location_id VARCHAR(50) = LTRIM(RTRIM(dbo.fn_get_location_in_store(@latitude, @longitude)));

    -------------------------------------------------------------------------
    -- 2) Preparar tabla variable para destinos intermedios
    -------------------------------------------------------------------------
    DECLARE @destinos_mid TABLE (
        DESTINATION_ID_STR VARCHAR(50),
        DESTINATION_NAME   VARCHAR(250)
    );

    -- CTE + INSERT (el CTE va seguido de un SELECT inmediato dentro del INSERT)
    ;WITH destinos AS (
        SELECT 
            CAST(LTRIM(RTRIM(CAST(TOR.DESTINATION_ID AS VARCHAR(50)))) AS VARCHAR(50)) AS DESTINATION_ID_STR,
            TOR.DESTINATION_NAME,
            ROW_NUMBER() OVER (ORDER BY TOR.DESTINATION_ORDER ASC) AS rn,
            COUNT(*) OVER() AS total_rows
        FROM T_ORDER TOR
		INNER JOIN T_TRAVEL_ACTUAL TTA ON TTA.TRAVEL_ID = TOR.TRAVEL_ID
		INNER JOIN T_TRAVEL TT ON TT.TRAVEL_ID = TTA.TRAVEL_ID AND TT.TRAVEL_END_DATE IS NULL
        WHERE TTA.GEAR_ID = @truck_id
    )
    INSERT INTO @destinos_mid (DESTINATION_ID_STR, DESTINATION_NAME)
    SELECT DESTINATION_ID_STR, DESTINATION_NAME
    FROM destinos
    WHERE rn > 1
      AND rn < total_rows;

    -------------------------------------------------------------------------
    -- 3) Comparaci�n contra destinos intermedios
    -------------------------------------------------------------------------
    DECLARE @coincide        BIT         = 0,
            @match_dest_id   VARCHAR(50) = NULL,
            @match_dest_name VARCHAR(250)= NULL;

    SELECT TOP (1)
        @coincide       = 1,
        @match_dest_id  = d.DESTINATION_ID_STR,
        @match_dest_name= d.DESTINATION_NAME
    FROM @destinos_mid d
    WHERE d.DESTINATION_ID_STR = @location_id;

    -------------------------------------------------------------------------
    -- 4) Diferencia de tiempo contra �ltima posici�n de T_TRUCK_T1
    -------------------------------------------------------------------------
    DECLARE @last_position    DATETIME2(0) = (
        SELECT MAX(POSITION_DATE)
        FROM T_TAUP_ONLINE
        WHERE TRUCK_ID = @truck_id
    );

    DECLARE @elapsed_seconds INT;

    IF @last_position IS NOT NULL
        SET @elapsed_seconds = DATEDIFF(SECOND, @last_position, @position_date);
    ELSE
        SET @elapsed_seconds = 0;   -- sin hist�rico, no alertamos por tiempo

    -------------------------------------------------------------------------
    -- 5) Status code y mensaje
    -------------------------------------------------------------------------
    DECLARE @status_code INT;         -- 0/1/2
    DECLARE @status_text NVARCHAR(30);
    DECLARE @mensaje     NVARCHAR(500);

    IF @coincide = 1
    BEGIN
        SET @status_code = 0;
        SET @status_text = N'IN_ROUTE';
        SET @mensaje = CONCAT(
            N'OK: ubicaci�n coincide con destino intermedio (',
            @match_dest_id, N' - ', @match_dest_name, N').'
        );
    END
    ELSE
    BEGIN
        IF @elapsed_seconds >= @threshold_seconds
        BEGIN
            SET @status_code = 2;
            SET @status_text = N'ALERT';
            SET @mensaje = CONCAT(
                N'ALERTA: fuera de ruta y sin nueva posici�n por ',
                @elapsed_seconds, N' seg (umbral: ', @threshold_seconds, N' seg).'
            );
        END
        ELSE
        BEGIN
            SET @status_code = 1;
            SET @status_text = N'OFF_ROUTE_WITHIN_THRESHOLD';
            SET @mensaje = CONCAT(
                N'Fuera de ruta, pero dentro del umbral de tiempo (',
                @elapsed_seconds, N'/', @threshold_seconds, N' seg).'
            );
        END
    END

    -------------------------------------------------------------------------
    -- 6) Resultado
    -------------------------------------------------------------------------
    SELECT
        STATUS_CODE           = @status_code,      -- 0/1/2
        STATUS_TEXT           = @status_text,       -- IN_ROUTE / OFF_ROUTE_WITHIN_THRESHOLD / ALERT
        MENSAJE               = @mensaje;
        /*LOCATION_ID_DETECTADO = @location_id,
        COINCIDE_CON_DESTINO  = @coincide,
        DESTINO_ID_MATCH      = @match_dest_id,
        DESTINO_NOMBRE_MATCH  = @match_dest_name,
        ULTIMA_POSICION       = @last_position,
        NUEVA_POSICION        = @position_date,
        ELAPSED_SECONDS       = @elapsed_seconds,
        THRESHOLD_SECONDS     = @threshold_seconds;*/
END
GO
